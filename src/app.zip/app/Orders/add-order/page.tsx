"use client";

import React, { useState, useEffect } from 'react';
import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from '@/components/ui/label';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { X } from "lucide-react";

interface OrderFormModalProps {
  open: boolean;
  setOpen: (open: boolean) => void;
}

interface FormData {
  partyLedger: string;
  subname: string;
  product: string;
  purity: string;
  advanceMetal: string;
  advanceMetalPurity: string;
  priority: string;
  deliveryDate: string;
  remark: string;
  createdBy: string;
  category?: string;
  wtRange?: string;
  size?: string;
  quantity?: string;
  itemRemark?: string;
}

interface OrderInfo {
  partyCode: string;
  partyName: string;
  orderNo: string;
  orderDate: string;
  category: string;
  purity: string;
  advanceMetal: string;
  advanceMetalPurity: string;
  priority: string;
  deliveryDate: string;
  remark: string;
  createdBy: string;
  status: string;
  pdfBlob?: Blob;
}

interface OrderItem {
  category: string;
  weightRange: string;
  size: string;
  quantity: string;
  remark: string;
}

const OrderFormModal = ({ open, setOpen }: OrderFormModalProps) => {
  

  // State
  const [orderInfo, setOrderInfo] = useState<OrderInfo | null>(null);
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [partyLedgers, setPartyLedgers] = useState<string[]>([]);
  const [isOrderSaved, setIsOrderSaved] = useState(false);

  // Form state
  const [formData, setFormData] = useState<FormData>({
    partyLedger: '',
    subname: '',
    product: '',
    purity: '',
    advanceMetal: '',
    advanceMetalPurity: '',
    priority: '',
    deliveryDate: '',
    remark: '',
    createdBy: '',
    category: '',
    wtRange: '',
    size: '',
    quantity: '',
    itemRemark: ''
  });

  // API base URL
  const apiBaseUrl = "https://needha-erp-server.onrender.com";

  useEffect(() => {
    fetchPartyLedgers();
  }, []);

  const fetchPartyLedgers = async () => {
    try {
      const response = await fetch(`${apiBaseUrl}/customer-groups`);
      const result = await response.json();
      
      if (response.ok && result.success) {
        setPartyLedgers(result.data.map((ledger: any) => ledger.Party_Code__c));
      }
    } catch (error) {
      console.error('Error fetching party ledgers:', error);
    }
  };

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSaveOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (!formData.partyLedger) {
        throw new Error('Please select a valid Party Ledger');
      }

      const orderNo = await getNextOrderNumber(formData.partyLedger);
      
      const newOrderInfo: OrderInfo = {
        partyCode: formData.partyLedger,
        partyName: formData.subname,
        orderNo,
        orderDate: new Date().toLocaleDateString(),
        category: formData.product,
        purity: formData.purity,
        advanceMetal: formData.advanceMetal,
        advanceMetalPurity: formData.advanceMetalPurity,
        priority: formData.priority,
        deliveryDate: formData.deliveryDate,
        remark: formData.remark,
        createdBy: formData.createdBy,
        status: "Pending"
      };

      if (!validateOrderInfo(newOrderInfo)) {
        throw new Error('Please fill in all required fields');
      }

      setOrderInfo(newOrderInfo);
      setIsOrderSaved(true);

    } catch (error: any) {
      alert(error.message);
      console.error('Error saving order:', error);
    }
  };

  const handleAddItem = () => {
    if (!orderInfo) {
      alert('Please save the order information first');
      return;
    }

    const newItem: OrderItem = {
      category: formData.category || '',
      weightRange: formData.wtRange || '',
      size: formData.size || '',
      quantity: formData.quantity || '',
      remark: formData.itemRemark || ''
    };

    if (!validateItem(newItem)) {
      alert('Please fill in all required fields for the item');
      return;
    }

    setOrderItems(prev => [...prev, newItem]);
    
    // Clear item form fields
    setFormData(prev => ({
      ...prev,
      category: '',
      wtRange: '',
      size: '',
      quantity: '',
      itemRemark: ''
    }));
  };

  const handleRemoveItem = (index: number) => {
    setOrderItems(prev => prev.filter((_, i) => i !== index));
  };

  const getNextOrderNumber = async (partyCode: string) => {
    try {
      const response = await fetch(`${apiBaseUrl}/api/getLastOrderNumber?partyLedgerValue=${partyCode}`);
      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'Failed to get order number');
      }

      let sequence = '0001';
      if (data.lastOrderNumber) {
        const parts = data.lastOrderNumber.split('/');
        if (parts.length === 2 && /^\d{4}$/.test(parts[1])) {
          sequence = (parseInt(parts[1], 10) + 1).toString().padStart(4, '0');
        }
      }

      return `${partyCode}/${sequence}`;

    } catch (error) {
      console.error('Error generating order number:', error);
      throw error;
    }
  };

  const validateOrderInfo = (info: OrderInfo): boolean => {
    const requiredFields: (keyof OrderInfo)[] = [
      'partyCode', 'partyName', 'advanceMetal',
      'advanceMetalPurity', 'priority', 'deliveryDate', 'createdBy'
    ];
    
    return requiredFields.every(field => Boolean(info[field]));
  };

  const validateItem = (item: OrderItem): boolean => {
    return Boolean(
      item.category &&
      item.weightRange &&
      item.size &&
      item.quantity
    );
  };

  const formatDateForSalesforce = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toISOString().split('T')[0];
  };

  const generatePDF = async () => {
    if (!orderInfo || orderItems.length === 0) {
      alert('No order information or items available');
      return;
    }

    try {
      const pdfDoc = await PDFDocument.create();
      const helveticaFont = await pdfDoc.embedFont(StandardFonts.Helvetica);
      const helveticaBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
      
      // Add page
      const page = pdfDoc.addPage([595.28, 841.89]); // A4 size

      // Add header
      page.drawText('Needha Gold Order Invoice', {
        x: 50,
        y: 800,
        size: 20,
        font: helveticaBold
      });

      // Add order details
      let y = 750;
      [
        ['Order No:', orderInfo.orderNo],
        ['Customer:', orderInfo.partyName],
        ['Date:', orderInfo.orderDate]
      ].forEach(([label, value]) => {
        page.drawText(`${label} ${value}`, {
          x: 50,
          y,
          size: 12,
          font: helveticaFont
        });
        y -= 20;
      });

      const pdfBytes = await pdfDoc.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);

      window.open(url, '_blank');

      setOrderInfo(prev => prev ? {
        ...prev,
        pdfBlob: blob
      } : null);

    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Error generating PDF');
    }
  };

  const handleSubmitOrder = async () => {
    try {
      if (!orderInfo) {
        throw new Error('Please save the order information first');
      }

      if (orderItems.length === 0) {
        throw new Error('Please add at least one item to the order');
      }

      const formData = new FormData();
      
      if (orderInfo.pdfBlob) {
        formData.append('pdfFile', orderInfo.pdfBlob, `order_${orderInfo.orderNo}.pdf`);
      }
      
      const completeOrder = {
        orderInfo: {
          ...orderInfo,
          deliveryDate: formatDateForSalesforce(orderInfo.deliveryDate),
          orderDate: formatDateForSalesforce(new Date().toLocaleDateString())
        },
        items: orderItems
      };
      
      formData.append('orderData', JSON.stringify(completeOrder));

      const response = await fetch(`${apiBaseUrl}/api/orders`, {
        method: "POST",
        body: formData
      });

      if (!response.ok) {
        throw new Error('Failed to submit order');
      }

      // Reset form
      setFormData({
        partyLedger: '',
        subname: '',
        product: '',
        purity: '',
        advanceMetal: '',
        advanceMetalPurity: '',
        priority: '',
        deliveryDate: '',
        remark: '',
        createdBy: '',
        category: '',
        wtRange: '',
        size: '',
        quantity: '',
        itemRemark: ''
      });
      
      setOrderInfo(null);
      setOrderItems([]);
      setIsOrderSaved(false);

      alert('Order submitted successfully!');

    } catch (error: any) {
      alert(error.message);
      console.error('Error submitting order:', error);
    }
}
return (
    <div className="container mx-auto p-4 space-y-6">
      <h1 className="text-2xl font-bold mb-6">Orders</h1>

      {/* Main form container */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Add Order Card */}
        <Card>
          <CardHeader>
            <CardTitle>Add Order</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Party Ledger */}
            <div className="space-y-2">
              <Label htmlFor="partyLedger">Party Ledger</Label>
              <Select 
                value={formData.partyLedger}
                onValueChange={(value) => handleInputChange('partyLedger', value)}
                disabled={isOrderSaved}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select Party Ledger" />
                </SelectTrigger>
                <SelectContent>
                  {partyLedgers.map((ledger) => (
                    <SelectItem key={ledger} value={ledger}>
                      {ledger}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Subname */}
            <div className="space-y-2">
              <Label htmlFor="subname">Subname</Label>
              <Input
                id="subname"
                value={formData.subname}
                onChange={(e) => handleInputChange('subname', e.target.value)}
                placeholder="Enter subname"
                disabled={isOrderSaved}
              />
            </div>

            {/* Product */}
            <div className="space-y-2">
              <Label htmlFor="product">Product</Label>
              <Input
                id="product"
                value={formData.product}
                onChange={(e) => handleInputChange('product', e.target.value)}
                placeholder="Enter product"
                disabled={isOrderSaved}
              />
            </div>

            {/* Purity */}
            <div className="space-y-2">
              <Label htmlFor="purity">Purity</Label>
              <Select 
                value={formData.purity}
                onValueChange={(value) => handleInputChange('purity', value)}
                disabled={isOrderSaved}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select Purity" />
                </SelectTrigger>
                <SelectContent>
                  {['24K', '22K', '18K', '14K'].map((purity) => (
                    <SelectItem key={purity} value={purity}>
                      {purity}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Advance Metal */}
            <div className="space-y-2">
              <Label htmlFor="advanceMetal">Advance Metal</Label>
              <Input
                id="advanceMetal"
                value={formData.advanceMetal}
                onChange={(e) => handleInputChange('advanceMetal', e.target.value)}
                placeholder="Enter advance metal"
                disabled={isOrderSaved}
              />
            </div>

            {/* Advance Metal Purity */}
            <div className="space-y-2">
              <Label htmlFor="advanceMetalPurity">Advance Metal Purity</Label>
              <Input
                id="advanceMetalPurity"
                value={formData.advanceMetalPurity}
                onChange={(e) => handleInputChange('advanceMetalPurity', e.target.value)}
                placeholder="Enter advance metal purity"
                disabled={isOrderSaved}
              />
            </div>

            {/* Priority */}
            <div className="space-y-2">
              <Label htmlFor="priority">Priority</Label>
              <Select 
                value={formData.priority}
                onValueChange={(value) => handleInputChange('priority', value)}
                disabled={isOrderSaved}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select Priority" />
                </SelectTrigger>
                <SelectContent>
                  {['High', 'Mid', 'Low'].map((priority) => (
                    <SelectItem key={priority} value={priority}>
                      {priority}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="deliveryDate">Delivery Date</Label>
              <Input
                id="deliveryDate"
                type="date"
                value={formData.deliveryDate}
                onChange={(e) => handleInputChange('deliveryDate', e.target.value)}
                disabled={isOrderSaved}
              />
            </div>

            {/* Remark */}
            <div className="space-y-2">
              <Label htmlFor="remark">Remark</Label>
              <Input
                id="remark"
                value={formData.remark}
                onChange={(e) => handleInputChange('remark', e.target.value)}
                placeholder="Enter remark"
                disabled={isOrderSaved}
              />
            </div>

            {/* Created By */}
            <div className="space-y-2">
              <Label htmlFor="createdBy">Created By</Label>
              <Input
                id="createdBy"
                value={formData.createdBy}
                onChange={(e) => handleInputChange('createdBy', e.target.value)}
                placeholder="Enter created by"
                disabled={isOrderSaved}
              />
            </div>

            <Button 
              className="w-full"
              onClick={handleSaveOrder}
              disabled={isOrderSaved}
            >
              Save Order
            </Button>
          </CardContent>
        </Card>

        {/* Add Item Card */}
        <Card>
          <CardHeader>
            <CardTitle>Add Item</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Category */}
            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Input
                id="category"
                value={formData.category}
                onChange={(e) => handleInputChange('category', e.target.value)}
                placeholder="Enter category"
                disabled={!isOrderSaved}
              />
            </div>

            {/* Weight Range */}
            <div className="space-y-2">
              <Label htmlFor="wtRange">Weight Range</Label>
              <Input
                id="wtRange"
                value={formData.wtRange}
                onChange={(e) => handleInputChange('wtRange', e.target.value)}
                placeholder="Enter weight range"
                disabled={!isOrderSaved}
              />
            </div>

            {/* Size */}
            <div className="space-y-2">
              <Label htmlFor="size">Size</Label>
              <Input
                id="size"
                value={formData.size}
                onChange={(e) => handleInputChange('size', e.target.value)}
                placeholder="Enter size"
                disabled={!isOrderSaved}
              />
            </div>

            {/* Quantity */}
            <div className="space-y-2">
              <Label htmlFor="quantity">Quantity</Label>
              <Input
                id="quantity"
                type="number"
                value={formData.quantity}
                onChange={(e) => handleInputChange('quantity', e.target.value)}
                placeholder="Enter quantity"
                min="1"
                disabled={!isOrderSaved}
              />
            </div>

            {/* Item Remark */}
            <div className="space-y-2">
              <Label htmlFor="itemRemark">Remark</Label>
              <Input
                id="itemRemark"
                value={formData.itemRemark}
                onChange={(e) => handleInputChange('itemRemark', e.target.value)}
                placeholder="Enter remark"
                disabled={!isOrderSaved}
              />
            </div>

            <Button 
              className="w-full"
              onClick={handleAddItem}
              disabled={!isOrderSaved}
            >
              Add Item
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Order Information Card */}
      {orderInfo && (
        <Card>
          <CardHeader>
            <CardTitle>Order Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr>
                    <th rowSpan={2} className="border px-4 py-2">Party Code</th>
                    <th rowSpan={2} className="border px-4 py-2">Party Name</th>
                    <th rowSpan={2} className="border px-4 py-2">Order No</th>
                    <th rowSpan={2} className="border px-4 py-2">Order Date</th>
                    <th rowSpan={2} className="border px-4 py-2">Product</th>
                    <th rowSpan={2} className="border px-4 py-2">Purity</th>
                    <th colSpan={2} className="border px-4 py-2">Advance Metal Details</th>
                    <th colSpan={3} className="border px-4 py-2">Order Details</th>
                  </tr>
                  <tr>
                    <th className="border px-4 py-2">Metal</th>
                    <th className="border px-4 py-2">Metal Purity</th>
                    <th className="border px-4 py-2">Priority</th>
                    <th className="border px-4 py-2">Delivery Date</th>
                    <th className="border px-4 py-2">Created By</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border px-4 py-2">{orderInfo.partyCode}</td>
                    <td className="border px-4 py-2">{orderInfo.partyName}</td>
                    <td className="border px-4 py-2">{orderInfo.orderNo}</td>
                    <td className="border px-4 py-2">{orderInfo.orderDate}</td>
                    <td className="border px-4 py-2">{orderInfo.category}</td>
                    <td className="border px-4 py-2">{orderInfo.purity}</td>
                    <td className="border px-4 py-2">{orderInfo.advanceMetal}</td>
                    <td className="border px-4 py-2">{orderInfo.advanceMetalPurity}</td>
                    <td className="border px-4 py-2">{orderInfo.priority}</td>
                    <td className="border px-4 py-2">{orderInfo.deliveryDate}</td>
                    <td className="border px-4 py-2">{orderInfo.createdBy}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Order Items Card */}
      {orderItems.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Order Items</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr>
                    <th className="border px-4 py-2">Category</th>
                    <th className="border px-4 py-2">Weight Range</th>
                    <th className="border px-4 py-2">Size</th>
                    <th className="border px-4 py-2">Quantity</th>
                    <th className="border px-4 py-2">Remarks</th>
                    <th className="border px-4 py-2">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {orderItems.map((item, index) => (
                    <tr key={index}>
                      <td className="border px-4 py-2">{item.category}</td>
                      <td className="border px-4 py-2">{item.weightRange}</td>
                      <td className="border px-4 py-2">{item.size}</td>
                      <td className="border px-4 py-2">{item.quantity}</td>
                      <td className="border px-4 py-2">{item.remark}</td>
                      <td className="border px-4 py-2">
                        <Button
                          onClick={() => handleRemoveItem(index)}
                        >
                          Remove
                        </Button>
                      </td>
                    </tr>
                  ))}
                  <tr>
                    <td colSpan={3} className="border px-4 py-2 font-bold text-right">Total:</td>
                    <td className="border px-4 py-2 font-bold">
                      {orderItems.reduce((sum, item) => sum + parseInt(item.quantity || '0'), 0)}
                    </td>
                    <td colSpan={2} className="border px-4 py-2"></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Action Buttons */}
      <div className="flex justify-center gap-4">
        <Button 
          onClick={handleSubmitOrder}
          disabled={!isOrderSaved || orderItems.length === 0}
          className="bg-blue-500 hover:bg-blue-600"
        >
          Submit Order
        </Button>
        <Button 
          onClick={generatePDF}
          disabled={!isOrderSaved || orderItems.length === 0}
        >
          Generate PDF
        </Button>
      </div>
    </div>
      
      );   
              };          // Closes the return statement           // Closes the OrderFormModal component
    
    export default OrderFormModal;